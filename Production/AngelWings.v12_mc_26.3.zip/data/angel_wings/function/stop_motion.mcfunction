$tp @s ~ $(y) ~
